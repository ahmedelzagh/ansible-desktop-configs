autoload -Uz genpass-apple genpass-monkey genpass-xkcd
